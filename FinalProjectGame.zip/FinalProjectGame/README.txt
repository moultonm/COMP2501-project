GOOBY'S SPACE ADVENTURE

Authors:
Alexandra Wilson (100998162)
Matthew Moulton (101010631)

DEPENDENCIES:
- standard sfml setup, but MAKE SURE you include "sfml-audio.lib" and
  "sfml-audio-d.lib" now so you don't run into issues with music later!!!!

FILES:
main.cpp
Game.h
Game.cpp
Model.cpp
Model.h
View.h
View.cpp
Control.h
Control.cpp
