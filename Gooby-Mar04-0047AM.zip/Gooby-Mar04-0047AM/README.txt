UPDATES AS OF MARCH 4 AT 12:47 AM:
- by Alex-

- this code has a working crafting system and a working level selection screen
- changes to PLAYER:
	- took the items vector away from the player
- changes to MODEL:
	- gave a levelscreen and crafting obj
	- gave an items vector
- changes to VIEW:
	 - added a few extra lines of code to properly display new screens
- changes to CONTROL:
	- so so so much
	- changed the way that some of the key press events are listened for in inputs
	- added level screen and crafting control via input
	- oh sweet neptune there's a lot of code
- changes to DEFS:
	- added a couple of game states