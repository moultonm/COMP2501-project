#pragma once

//gamestate constants
#define TITLE 0
#define GAME 1
#define CRAFT 2
#define LEVEL 3
#define CENTER_SCREEN 450 //the "middle of the screen" to lock our camera to the player
