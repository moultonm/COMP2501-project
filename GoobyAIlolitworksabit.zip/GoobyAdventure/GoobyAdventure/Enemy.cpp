#include "Enemy.h"

Enemy::Enemy(int x, int y) {
	accumulatedTime = sf::seconds(0);
	position.x = x;
	position.y = y;
	velocity.x = 0;
	velocity.y = 0;
	speed = 125;
	//sprite.setOrigin(52, 54);
}

Enemy::~Enemy() {

}

void Enemy::update(sf::Time deltaTime) {
	std::cout << "I'm in here!!!" << std::endl;
}

void Enemy::update(sf::Time deltaTime, Player* p) {
	accumulatedTime += deltaTime;

	// move towards the player if they're within 200 pixels
	// attack player if they're within 100 pixels
	// 

	//if (accumulatedTime.asSeconds() > 3) { //every 4 seconds
		if (p->position.x - this->position.x > -200 && p->position.x - this->position.x < 200) { //enemy randomly starts moving left or right
			if (p->position.x < this->position.x) velocity.x = -speed;
			else velocity.x = +speed;
		}
		
	//}


	if (p->position.x -this->position.x >-300 && p->position.x - this->position.x < 300) {
		if (accumulatedTime.asSeconds() >= 1) {
			this->attack(p);
			accumulatedTime = sf::seconds(0);
		}
	}
	

	//for (int i = 0; i < bullets.size(); i++) {
	//	bullets[i]->update(deltaTime);
	//}

	position.x += velocity.x * deltaTime.asSeconds();
	if (position.x < 0) velocity.x = +speed; //don't let the enemies leave the left bound of the screen
	sprite.setPosition(position);
}


void Enemy::attack(Player* p) {
		if (p->position.x < this->position.x) {
			bullets.push_back(new Bullet(this->position.x, this->position.y, -(150+velocity.x), 0+velocity.y));
		}
		else {
			bullets.push_back(new Bullet(this->position.x, this->position.y, 150+velocity.x, 0+velocity.y));
		}
	
}