#include "BoingBullet.h"

BoingBullet::BoingBullet(float x, float y, float velx, float vely) : Bullet(x,y,velx,vely) {


}

BoingBullet::~BoingBullet() {}