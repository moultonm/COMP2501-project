#pragma once
#include "Updateable.h"
#include "Renderable.h"
#include "Player.h"
#include "Bullet.h"
#include "FireBullet.h"
#include "BoingBullet.h"
#include <cmath>
#include <iostream>
#include <vector>
#include "defs.h"

class Enemy : public Updateable, public Renderable {
public:
	Enemy(int x=CENTER_SCREEN, int y=600); //constructs our enemy at a given x,y coordinate
	~Enemy();
	void attack(Player* p);

	virtual void update(sf::Time);
	void update(sf::Time, Player* p); //Enemy updates his position based on his velocity?

	sf::Vector2f velocity;
	std::vector<Bullet*> bullets;

	int speed; //the rate that velocity increments when the Enemy moves
	sf::Time accumulatedTime; //enemy may change behaviour after some time passes
};
