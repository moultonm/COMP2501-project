#include "FireBullet.h"

FireBullet::FireBullet(float x, float y, float velx, float vely) : Bullet(x,y,velx,vely) {


}

FireBullet::~FireBullet() {}