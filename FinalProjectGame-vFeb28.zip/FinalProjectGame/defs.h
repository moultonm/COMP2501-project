#pragma once

//gamestate constants
#define TITLE 0
#define GAME 1
#define CENTER 450 //the "middle of the screen" to lock our camera to the player