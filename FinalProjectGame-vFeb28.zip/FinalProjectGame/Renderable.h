#pragma once
#include <SFML/Graphics.hpp>

class Renderable {
public:
	sf::Sprite sprite; //renderables are all textured sprites that can be drawn
};
