GOOBY'S SPACE ADVENTURE

Authors:
Alexandra Wilson (100998162)
Matthew Moulton (101010 something)

DEPENDENCIES:
- standard sfml setup, but MAKE SURE you include "sfml-audio.lib" and 
  "sfml-audio-d.lib" now so you don't run into issues with music later!!!!

-- Latest Updates:
	- added in crafting and items, and currently working on implementing the menu itself and adding more items and working on the UI for the crafting menu.

Goals Right Now (for Alex):
Monday/Tuesday: Crafting
Wednesday: Level Menu
Thursday/Friday: Actual game play and level building for regular levels
Friday/Saturday: Boss level/game play

For saturday we need proof of concept, so it doesn't have to be 100% fancy but we'll do as much as we can, of course

FILES:
Control.cpp
Control.h
Crafting.cpp
Crafting.h
defs.h
Game.h
Game.cpp
Item.cpp
Item.h
main.cpp
Manager.cpp
Manager.h
Model.cpp
Model.h
Player.cpp
Player.h
Renderable.h
Updateable.h
View.cpp
View.h