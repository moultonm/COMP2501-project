#include "Model.h"

Model::Model() {
	spawner = sf::seconds(0);
	score = 0;
	crafting = new Crafting();
	levelScreen = new LevelScreen();
	items.reserve(5);
	items.push_back(new Item(1, "bullet"));
	items.push_back(new Item(1, "flux capacitor"));

	//make some platforms just to try em out
	for (int i = 0; i < 20; i++) {
		platforms.push_back(new Platform(240 * i, rand() % 116 + 532, rand() % 110 + 50, rand() % 50 + 10));
	}
}

Model::~Model() {

}

void Model::update(sf::Time deltaTime) {
	if (*gameState != GAME) {
		return; //don't update anything if we haven't started the game yet
	}
	

	/*-----spawn new enemies into the game-----*/
	spawner += deltaTime;
	if (spawner.asSeconds() > 4) { //every 4 seconds
		enemies.push_back(new Enemy(rand() % (2 * CENTER_SCREEN))); //spawn a new enemy randomly on the screen
		spawner = sf::seconds(0);
	}

	/*-----updateables-----*/
	for (int i = 0; i < updateables.size(); i++) {
		updateables[i]->update(deltaTime);
	}

	/*-----check if player is on a platform-----*/
	for (int i = 0; i < platforms.size(); i++) {
		if (player->position.x + 60 > platforms[i]->x && player->position.x + 40 < platforms[i]->x + platforms[i]->width
			&& player->position.y + 75 <= platforms[i]->y) { //have to mess with the player's coordinates since the sprite is crappy
			player->groundLevel = platforms[i]->y - 75; //set groundlevel to the platform we are on (-75 is to match the sprites feet instead of his top box)
			break;
		}
		else if (!(player->position.x + 35 > platforms[i]->x && player->position.x + 35 < platforms[i]->x + platforms[i]->width)) { //reset groundlevel if we aren't on a platform
			player->groundLevel = 600; //this value is the "floor" level, can be updated for each level once levels are designed

		}
	}

	/*-----update enemies-----*/
	for (int i = 0; i < enemies.size(); i++) {
		enemies[i]->update(deltaTime);
		/*-----attempt to kill enemy by jumping on him-----*/
		if (player->isJumping && player->position.y + 22 > enemies[i]->position.y - 65 && player->position.y + 22 < enemies[i]->position.y + 15 &&
			player->position.x + 35 > enemies[i]->position.x + 10 && player->position.x + 35 < enemies[i]->position.x + 94) { //temporary magic numbers are to tighten the hitbox since the sprites aren't boxed well
			enemies.erase(enemies.begin() + i); //remove this enemy from the game
			score += 50;
		}
	}

	//DESPAWN BULLETS
	for (int i = 0; i < player->bullets.size(); i++) {
		if (player->bullets[i]->timeToLive < 0) {
			player->bullets.erase(player->bullets.begin() + i);
		}
	}

	//UPDATE BULLETS
	for (int i = 0; i < player->bullets.size(); i++) {
		player->bullets[i]->update(deltaTime);
	}

	//CHECK COLLISION WITH BULLETS
	for (int i = 0; i < player->bullets.size(); i++) {
		for (int j = 0; j < enemies.size(); j++) {
			if (pow((player->bullets[i]->position.x+32) - (enemies[j]->position.x+52), 2) +
				pow((player->bullets[i]->position.y+32) - (enemies[j]->position.y+54), 2) <=
				pow(32 + 26, 2)) {
				player->bullets.erase(player->bullets.begin() + i);
				enemies.erase(enemies.begin() + j);
				score += 50;
				break;
			}
		}
	}

	//CHECK COLLISION WITH PLAYER
	for (int j = 0; j < enemies.size(); j++) {
		player->sprite.setColor(sf::Color::Green);
		if (pow(player->position.x - enemies[j]->position.x, 2) +
			pow(player->position.y - enemies[j]->position.y, 2) <=
			pow(15 + 26, 2)) {
			//*gameState = 2; //game over
			player->sprite.setColor(sf::Color::Red); //for now show collision by updating color
			break;
		}
	}
} //bullet radius 32
//enemy radius -> 104x108
// 52,54 center .. 26 radius
//player 48,44   radius 15
