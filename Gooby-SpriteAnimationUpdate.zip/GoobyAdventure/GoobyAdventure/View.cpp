#include "View.h"

View::View(Model* m) {
	model = m;

	width = 1024;
	height = 700;

	hud = new HUD();
	model->player->sprite.setTexture(imageManager.get_texture("Assets/p1_spritesheet.png"));
	model->player->sprite.setTextureRect(sf::IntRect(67, 196, 66, 92));

	//initialize our window
	window.create(sf::VideoMode(width, height), "COMP2501-Gooby_Space_Adventure");
	window.setFramerateLimit(45);

	//initializes title text for now
	font.loadFromFile("Assets/Escalope_Crust-One.ttf");
	text.setFont(font);
	text.setFillColor(sf::Color::Magenta);
	text.setCharacterSize(65);
	text.setPosition(width / 4, height / 4);
	text.setString("Gooby's Space Adventure\n\n        (Press Space)");

	//background is just the same image repeated twice and it loops forever rightwards
	for (int i = 0; i < 2; i++) {
		backgroundSprites.push_back(sf::Sprite());
		backgroundSprites.back().setTexture(imageManager.get_texture("Assets/backgroundSmall.png"), true);
		backgroundSprites.back().setPosition((1024 * i) - (CENTER_SCREEN % 1024), 0);
	}
}

View::~View() {

}

void View::render() {
	window.clear(sf::Color::Black);

	if (*gameState == TITLE) {
		window.draw(text);
		window.display();
	}
	else if (*gameState == CRAFT) {
		model->crafting->menu(model->items);
		model->crafting->render(&window);
		window.display();
	}
	else if (*gameState == LEVEL) {
		model->levelScreen->render(&window);
		window.display();
	}
	if (*gameState != GAME) {
		return; //don't draw anything else if we haven't started the game yet
	}

	/*-----draw the background-----*/
	if (model->player->centered) { //only scroll the background when player is center-screen
		backgroundSprites[0].setPosition(0 - ((int)model->player->position.x % 1024), 0); //modular position loops the background
		backgroundSprites[1].setPosition(1024 - ((int)model->player->position.x % 1024), 0);
	}
	window.draw(backgroundSprites[0]);
	window.draw(backgroundSprites[1]);

	/*-----handle the enemies-----*/
	for (int i = 0; i < model->enemies.size(); i++) {
		sf::Sprite enemy = model->enemies[i]->sprite;
		enemy.setTexture(imageManager.get_texture("Assets/goomba.bmp", sf::Color::White), true);
		if (model->player->centered) { //when player is centered, the goombas should not scroll with him..
			enemy.setPosition(CENTER_SCREEN + enemy.getPosition().x - model->player->position.x, enemy.getPosition().y);
		}
		window.draw(enemy);
	}

	/*-----draw platforms------*/
	for (int i = 0; i < model->platforms.size(); i++) {
		sf::VertexArray plat = model->platforms[i]->plat;
		if (model->player->centered) { //when player is centered, the platforms should not scroll with him..
			plat[0].position = sf::Vector2f(CENTER_SCREEN + plat[0].position.x - model->player->position.x, plat[0].position.y);
			plat[1].position = sf::Vector2f(CENTER_SCREEN + plat[1].position.x - model->player->position.x, plat[1].position.y);
			plat[2].position = sf::Vector2f(CENTER_SCREEN + plat[2].position.x - model->player->position.x, plat[2].position.y);
			plat[3].position = sf::Vector2f(CENTER_SCREEN + plat[3].position.x - model->player->position.x, plat[3].position.y);
			//plat.setPosition(CENTER_SCREEN + plat.getPosition().x - model->player->position.x, plat.getPosition().y);
		}
		sf::Texture platTex;
		platTex = imageManager.get_texture("Assets/grassHalf.png");
		platTex.setRepeated(true);
		window.draw(plat, &platTex);
	}

	/*-----render stuff-----*/
	for (int i = 0; i < renderables.size(); i++) {
		window.draw(renderables[i]->sprite);
	}

	//BULLETS
	for (int i = 0; i < model->player->bullets.size(); i++) {
		sf::Sprite currBullet = model->player->bullets[i]->sprite;
		currBullet.setTexture(imageManager.get_texture("Assets/bulletRight.png"), true);
		if (model->player->centered) { //when player is centered, the goombas should not scroll with him..
			currBullet.setPosition(CENTER_SCREEN + model->player->bullets[i]->position.x - model->player->position.x, model->player->bullets[i]->position.y);
		}
		//currBullet.setPosition((model->player->bullets[i]->x*xOffset) + (MID_X + 32) - (model->player->x * xOffset), (model->player->bullets[i]->y*yOffset) + (MID_Y + 32) - (model->player->y*yOffset));
		window.draw(currBullet);
	}

	ss.str(""); //clear and update score UI
	ss << "Score: " << model->score;
	text.setString(ss.str());
	hud->render(&window);
	window.draw(text);
	window.display();
}
/*
std::stringstream ss;
ss.str("");
ss << "Score: " << model->score;
text.setString(ss.str()); //displays the score during the game

//TEXT
font.loadFromFile("Assets/arial.ttf");
text.setFont(font);
text.setFillColor(sf::Color::Magenta);
text.setCharacterSize(14);
text.setPosition(5, 5);
*/