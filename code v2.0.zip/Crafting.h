#pragma once
#include <SFML/Graphics.hpp>
#include "defs.h"
#include "Item.h"
#include <vector>

class Crafting {
public:
	Crafting();
	~Crafting();
	void render(/*std::vector<Item>*,*/ sf::RenderWindow*);
	void craft(Item*, Item*, Item*);
	void menu();
	sf::Font font;
	sf::Text top;
	sf::Text itemDesc;
	sf::Text itemName;
private:


};