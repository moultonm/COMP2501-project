#pragma once

//gamestate constants
#define TITLE 0
#define GAME 1
#define CRAFT 2