#include "Crafting.h"

Crafting::Crafting() {
	font.loadFromFile("Assets/arial.ttf");
	top.setFont(font);
	top.setString("CRAFTING");
	top.setCharacterSize(50);
	top.setFillColor(sf::Color::Black);
	top.setPosition(sf::Vector2f(275, 50));
}

Crafting::~Crafting() {}

void Crafting::render(sf::RenderWindow* window) {
	window->clear(sf::Color::White);
	window->draw(top);
}

void Crafting::menu() {
	

}

void Crafting::craft(Item* one, Item* two, Item* toMake) {
	//check what item one is against item two
	if (one->getTier() != 1 || two->getTier() != 1) {
		return;
	}

	if (one->getName() == "bullet") {
		if (two->getName() == "flux capacitor") {
			toMake = new Item(2, "fire gun");
		}
	}
}