GOOBY'S SPACE ADVENTURE

Authors:
Alexandra Wilson (100998162)
Matthew Moulton (101010631)

DEPENDENCIES:
- standard sfml setup, but MAKE SURE you include "sfml-audio.lib" and
  "sfml-audio-d.lib" now so you don't run into issues with music later!!!!

Source Files:
main.cpp
Game.cpp
Model.cpp
View.cpp
Control.cpp
Manager.cpp
Player.cpp

Header Files:
Game.h
Model.h
View.h
Control.h
Manager.h
Player.h
Renderable.h
Updateable.h
defs.h