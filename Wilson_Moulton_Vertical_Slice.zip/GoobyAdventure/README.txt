GOOBY'S SPACE ADVENTURE - VERTICAL SLICE

Authors:
Alexandra Wilson (100998162)
Matthew Moulton (101010631)

DEPENDENCIES:
- standard sfml setup, but MAKE SURE you include "sfml-audio.lib" and 
  "sfml-audio-d.lib" now so you don't run into issues with music later!!!!

INSTRUCTIONS:
- use W/A to move up and down in menus
- W to jump, A/D for left/right in level screen
- ENTER to make a selection

FILES:
Control.cpp
Control.h
Crafting.cpp
Crafting.h
defs.h
Enemy.cpp
Enemy.h
Game.h
Game.cpp
Item.cpp
Item.h
HUD.cpp
HUD.h
LevelScreen.cpp
LevelScreen.h
main.cpp
Manager.cpp
Manager.h
Model.cpp
Model.h
Platform.cpp
Platform.h
Player.cpp
Player.h
Renderable.h
Updateable.h
View.cpp
View.h